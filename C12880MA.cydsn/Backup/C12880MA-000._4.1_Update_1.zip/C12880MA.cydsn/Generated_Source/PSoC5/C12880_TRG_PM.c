/*******************************************************************************
* File Name: C12880_TRG_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "C12880_TRG.h"

static C12880_TRG_backupStruct C12880_TRG_backup;


/*******************************************************************************
* Function Name: C12880_TRG_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_TRG_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void C12880_TRG_SaveConfig(void) 
{

    #if(!C12880_TRG_UsingFixedFunction)
        #if(!C12880_TRG_PWMModeIsCenterAligned)
            C12880_TRG_backup.PWMPeriod = C12880_TRG_ReadPeriod();
        #endif /* (!C12880_TRG_PWMModeIsCenterAligned) */
        C12880_TRG_backup.PWMUdb = C12880_TRG_ReadCounter();
        #if (C12880_TRG_UseStatus)
            C12880_TRG_backup.InterruptMaskValue = C12880_TRG_STATUS_MASK;
        #endif /* (C12880_TRG_UseStatus) */

        #if(C12880_TRG_DeadBandMode == C12880_TRG__B_PWM__DBM_256_CLOCKS || \
            C12880_TRG_DeadBandMode == C12880_TRG__B_PWM__DBM_2_4_CLOCKS)
            C12880_TRG_backup.PWMdeadBandValue = C12880_TRG_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(C12880_TRG_KillModeMinTime)
             C12880_TRG_backup.PWMKillCounterPeriod = C12880_TRG_ReadKillTime();
        #endif /* (C12880_TRG_KillModeMinTime) */

        #if(C12880_TRG_UseControl)
            C12880_TRG_backup.PWMControlRegister = C12880_TRG_ReadControlRegister();
        #endif /* (C12880_TRG_UseControl) */
    #endif  /* (!C12880_TRG_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: C12880_TRG_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_TRG_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void C12880_TRG_RestoreConfig(void) 
{
        #if(!C12880_TRG_UsingFixedFunction)
            #if(!C12880_TRG_PWMModeIsCenterAligned)
                C12880_TRG_WritePeriod(C12880_TRG_backup.PWMPeriod);
            #endif /* (!C12880_TRG_PWMModeIsCenterAligned) */

            C12880_TRG_WriteCounter(C12880_TRG_backup.PWMUdb);

            #if (C12880_TRG_UseStatus)
                C12880_TRG_STATUS_MASK = C12880_TRG_backup.InterruptMaskValue;
            #endif /* (C12880_TRG_UseStatus) */

            #if(C12880_TRG_DeadBandMode == C12880_TRG__B_PWM__DBM_256_CLOCKS || \
                C12880_TRG_DeadBandMode == C12880_TRG__B_PWM__DBM_2_4_CLOCKS)
                C12880_TRG_WriteDeadTime(C12880_TRG_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(C12880_TRG_KillModeMinTime)
                C12880_TRG_WriteKillTime(C12880_TRG_backup.PWMKillCounterPeriod);
            #endif /* (C12880_TRG_KillModeMinTime) */

            #if(C12880_TRG_UseControl)
                C12880_TRG_WriteControlRegister(C12880_TRG_backup.PWMControlRegister);
            #endif /* (C12880_TRG_UseControl) */
        #endif  /* (!C12880_TRG_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: C12880_TRG_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_TRG_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void C12880_TRG_Sleep(void) 
{
    #if(C12880_TRG_UseControl)
        if(C12880_TRG_CTRL_ENABLE == (C12880_TRG_CONTROL & C12880_TRG_CTRL_ENABLE))
        {
            /*Component is enabled */
            C12880_TRG_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            C12880_TRG_backup.PWMEnableState = 0u;
        }
    #endif /* (C12880_TRG_UseControl) */

    /* Stop component */
    C12880_TRG_Stop();

    /* Save registers configuration */
    C12880_TRG_SaveConfig();
}


/*******************************************************************************
* Function Name: C12880_TRG_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_TRG_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void C12880_TRG_Wakeup(void) 
{
     /* Restore registers values */
    C12880_TRG_RestoreConfig();

    if(C12880_TRG_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        C12880_TRG_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
