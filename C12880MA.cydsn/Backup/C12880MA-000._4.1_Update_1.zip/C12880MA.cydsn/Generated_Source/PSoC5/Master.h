/*******************************************************************************
* File Name: Master.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Master_H)
#define CY_CLOCK_Master_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void Master_Start(void) ;
void Master_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void Master_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void Master_StandbyPower(uint8 state) ;
void Master_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 Master_GetDividerRegister(void) ;
void Master_SetModeRegister(uint8 modeBitMask) ;
void Master_ClearModeRegister(uint8 modeBitMask) ;
uint8 Master_GetModeRegister(void) ;
void Master_SetSourceRegister(uint8 clkSource) ;
uint8 Master_GetSourceRegister(void) ;
#if defined(Master__CFG3)
void Master_SetPhaseRegister(uint8 clkPhase) ;
uint8 Master_GetPhaseRegister(void) ;
#endif /* defined(Master__CFG3) */

#define Master_Enable()                       Master_Start()
#define Master_Disable()                      Master_Stop()
#define Master_SetDivider(clkDivider)         Master_SetDividerRegister(clkDivider, 1u)
#define Master_SetDividerValue(clkDivider)    Master_SetDividerRegister((clkDivider) - 1u, 1u)
#define Master_SetMode(clkMode)               Master_SetModeRegister(clkMode)
#define Master_SetSource(clkSource)           Master_SetSourceRegister(clkSource)
#if defined(Master__CFG3)
#define Master_SetPhase(clkPhase)             Master_SetPhaseRegister(clkPhase)
#define Master_SetPhaseValue(clkPhase)        Master_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(Master__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define Master_CLKEN              (* (reg8 *) Master__PM_ACT_CFG)
#define Master_CLKEN_PTR          ((reg8 *) Master__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define Master_CLKSTBY            (* (reg8 *) Master__PM_STBY_CFG)
#define Master_CLKSTBY_PTR        ((reg8 *) Master__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define Master_DIV_LSB            (* (reg8 *) Master__CFG0)
#define Master_DIV_LSB_PTR        ((reg8 *) Master__CFG0)
#define Master_DIV_PTR            ((reg16 *) Master__CFG0)

/* Clock MSB divider configuration register. */
#define Master_DIV_MSB            (* (reg8 *) Master__CFG1)
#define Master_DIV_MSB_PTR        ((reg8 *) Master__CFG1)

/* Mode and source configuration register */
#define Master_MOD_SRC            (* (reg8 *) Master__CFG2)
#define Master_MOD_SRC_PTR        ((reg8 *) Master__CFG2)

#if defined(Master__CFG3)
/* Analog clock phase configuration register */
#define Master_PHASE              (* (reg8 *) Master__CFG3)
#define Master_PHASE_PTR          ((reg8 *) Master__CFG3)
#endif /* defined(Master__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define Master_CLKEN_MASK         Master__PM_ACT_MSK
#define Master_CLKSTBY_MASK       Master__PM_STBY_MSK

/* CFG2 field masks */
#define Master_SRC_SEL_MSK        Master__CFG2_SRC_SEL_MASK
#define Master_MODE_MASK          (~(Master_SRC_SEL_MSK))

#if defined(Master__CFG3)
/* CFG3 phase mask */
#define Master_PHASE_MASK         Master__CFG3_PHASE_DLY_MASK
#endif /* defined(Master__CFG3) */

#endif /* CY_CLOCK_Master_H */


/* [] END OF FILE */
