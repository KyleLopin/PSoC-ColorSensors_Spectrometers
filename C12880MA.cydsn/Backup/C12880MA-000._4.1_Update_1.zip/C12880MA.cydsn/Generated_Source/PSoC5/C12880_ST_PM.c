/*******************************************************************************
* File Name: C12880_ST_PM.c
* Version 3.30
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "C12880_ST.h"

static C12880_ST_backupStruct C12880_ST_backup;


/*******************************************************************************
* Function Name: C12880_ST_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_ST_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void C12880_ST_SaveConfig(void) 
{

    #if(!C12880_ST_UsingFixedFunction)
        #if(!C12880_ST_PWMModeIsCenterAligned)
            C12880_ST_backup.PWMPeriod = C12880_ST_ReadPeriod();
        #endif /* (!C12880_ST_PWMModeIsCenterAligned) */
        C12880_ST_backup.PWMUdb = C12880_ST_ReadCounter();
        #if (C12880_ST_UseStatus)
            C12880_ST_backup.InterruptMaskValue = C12880_ST_STATUS_MASK;
        #endif /* (C12880_ST_UseStatus) */

        #if(C12880_ST_DeadBandMode == C12880_ST__B_PWM__DBM_256_CLOCKS || \
            C12880_ST_DeadBandMode == C12880_ST__B_PWM__DBM_2_4_CLOCKS)
            C12880_ST_backup.PWMdeadBandValue = C12880_ST_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(C12880_ST_KillModeMinTime)
             C12880_ST_backup.PWMKillCounterPeriod = C12880_ST_ReadKillTime();
        #endif /* (C12880_ST_KillModeMinTime) */

        #if(C12880_ST_UseControl)
            C12880_ST_backup.PWMControlRegister = C12880_ST_ReadControlRegister();
        #endif /* (C12880_ST_UseControl) */
    #endif  /* (!C12880_ST_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: C12880_ST_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_ST_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void C12880_ST_RestoreConfig(void) 
{
        #if(!C12880_ST_UsingFixedFunction)
            #if(!C12880_ST_PWMModeIsCenterAligned)
                C12880_ST_WritePeriod(C12880_ST_backup.PWMPeriod);
            #endif /* (!C12880_ST_PWMModeIsCenterAligned) */

            C12880_ST_WriteCounter(C12880_ST_backup.PWMUdb);

            #if (C12880_ST_UseStatus)
                C12880_ST_STATUS_MASK = C12880_ST_backup.InterruptMaskValue;
            #endif /* (C12880_ST_UseStatus) */

            #if(C12880_ST_DeadBandMode == C12880_ST__B_PWM__DBM_256_CLOCKS || \
                C12880_ST_DeadBandMode == C12880_ST__B_PWM__DBM_2_4_CLOCKS)
                C12880_ST_WriteDeadTime(C12880_ST_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(C12880_ST_KillModeMinTime)
                C12880_ST_WriteKillTime(C12880_ST_backup.PWMKillCounterPeriod);
            #endif /* (C12880_ST_KillModeMinTime) */

            #if(C12880_ST_UseControl)
                C12880_ST_WriteControlRegister(C12880_ST_backup.PWMControlRegister);
            #endif /* (C12880_ST_UseControl) */
        #endif  /* (!C12880_ST_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: C12880_ST_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_ST_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void C12880_ST_Sleep(void) 
{
    #if(C12880_ST_UseControl)
        if(C12880_ST_CTRL_ENABLE == (C12880_ST_CONTROL & C12880_ST_CTRL_ENABLE))
        {
            /*Component is enabled */
            C12880_ST_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            C12880_ST_backup.PWMEnableState = 0u;
        }
    #endif /* (C12880_ST_UseControl) */

    /* Stop component */
    C12880_ST_Stop();

    /* Save registers configuration */
    C12880_ST_SaveConfig();
}


/*******************************************************************************
* Function Name: C12880_ST_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  C12880_ST_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void C12880_ST_Wakeup(void) 
{
     /* Restore registers values */
    C12880_ST_RestoreConfig();

    if(C12880_ST_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        C12880_ST_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
